<html>
<head>
<title></title>
<style>
.header {
  background-image: url('logo.jpg');
  background-repeat: no-repeat;
  background-color: rgba(0,1,1,0.8);
  padding: 65px ;
}
body{ background-image:url('staff.jpg');
      background-repeat:no-repeat;
	  background-size: 100% 100%;
     background-color:aliceblue;
}
a{

      background: lightblue;;
      border: 1.5px solid darkblue;
      color: darkblue;
      padding: 15px;
      text-decoration: none;

}
a:hover{
	 Background-color: steelblue;

     Color: aliceblue;

}
table { border-radius:25px;	

  border-collapse: collapse;
	color:lightcyan;
	 background-color: rgba(0,1,1,0.8);
  width: 100%;
}

th, td{
  text-align: center;
  padding: 8px;
}

tr:nth-child(even){ 
 color:black;
 background-color: aliceblue;}

th {
  background-color:lightblue;
  color: black;
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
 
}
img {
   border-radius: 50%;
   height: $imageSmall;
   width: $imageSmall;
}

</style>
</head>

<body>
<div class="header">
</div>

<p><center><br><br>
<a href="entry.php"><b>ENTER NEW DATA</b></a><br><br>
<table>
<td><font color="white"><br><H3>EDIT OLD DATA</H3><br></font>
</td>
</table>
</p>


</body>
</html>
<table >
<tr>
<th>Name</th>
<th>Gender</th>
<th>Email</th>
<th>Skills</th>
<th>Experience</th>
<th>Qualification</th>
<th>Address</th>
<th>Contact no.</th>
<th>Another no.</th>
<th>DOB</th>
<th>Merital Status</th>
<th></th>
<th></th>
<th></th>
</tr>
<?php


	$link=mysqli_connect("localhost","root","","final");

$q="select * from info ";
$q1=mysqli_query($link,$q);
while($a=mysqli_fetch_array($q1))
 { 
  
	echo "<tr>";
	   echo "<td>";
    echo "<img src='$a[12]' width='100' height='100' />";
   echo "</td>"; 
echo "<td>";
echo $a[1];
echo "</td>";
echo "<td>";
	echo $a[2];
	echo "</td>";
	echo "<td>";
	echo $a[3];
	echo "</td>";
	echo "<td>";
	echo $a[4];
	echo "</td>";
    echo "<td>";
	echo $a[10];
	echo "</td>";
	echo "<td>";
	echo $a[5];
	echo "</td>";
    echo "<td>";
	echo $a[6];
	echo "</td>";
	echo "<td>";
	echo $a[7];
	echo "</td>";
	echo "<td>";
	echo $a[8];
	echo "</td>";
	echo "<td>";
	echo $a[9];
	echo "</td>";

    echo "<td>";
	echo $a[11];
	echo "</td>";	
	
    echo "<td>";
	echo '<a href="del.php?Emailid='.$a[3].'">';
	echo "Delete";
	echo "</a>";
    echo "</td>";
	echo "<td>";
	echo '<a href="up.php?Emailid='.$a[3].'">';
	echo "Update";	
	echo "</td>";

  echo "</tr>";
  }


?>
</table>

