<?php

		$link=mysqli_connect('localhost','root','','final');
	$a=$_GET['Emailid'];
	
	$q="select * from info where Emailid='$a'";
	$q1=mysqli_query($link,$q);

	if($a=mysqli_fetch_array($q1))
	{
	?>
	<form action="#" method="post">
		
		<h1 align=center>TEACHERS DATA UPDATE</h1>
		<center>
	
 Name   <?php echo"<input type ='text' name='t1' value='$a[1]'>";?>  <br>
 Gender   <?php echo"<input type ='text' name='t2' value='$a[2]'>";?>  <br>
 Email id   <?php echo "<input type ='text' name ='t3' value='$a[3]'>";?><br>
 Skills   <?php echo"<input type ='text' name='ski' value='$a[4]'>";?>  <br>
 Teaching experience   <?php echo "<input type='text' name='t4' value='$a[5]'>";?><br>
 Qualification   <?php echo"<input type='text' name='qual' value='$a[6]'>";?><br>
 Address   <?php echo "<input type='text' name='add' value='$a[7]'>"; ?> <br>
 contact   <?php echo "<input type='text' name='con1' value='$a[8]'>"; ?><br>
 Another no.   <?php echo "<input type='text' name='con2' value='$a[9]'>"; ?><br>
 
 

	<input type="submit" name="s" value="Update">
		</center>
	</form>



<?php


$a1=$_POST['t1'];
$a2=$_POST['t2'];
$a3=$_POST['t3'];
$ski=$_POST['ski'];
$tec=$_POST['t4'];
$qua=$_POST['qual'];
$add=$_POST['add'];
$con1=$_POST['con1'];
$con2=$_POST['con2']; 



if(isset($_POST['s']))
{
	//echo $a1.$a2.$a3.$ski.$tec.$qua.$add.$con1.$con2;
$link=mysqli_connect('localhost','root','','final');		
//$q2="update info set Name='$a1',Gender='$a2' ,Emailid='$a3',Skills='$ski' ,Teaching exp.='$tec',Qualifications='$qua',Address='$add' , Contact no. 1='$con1',contact no. 2='con2' where Name='$a1'";
$q2="update info set Name='$a1' , Emailid='$a3' , Skills='$ski' , Gender='$a2' , Qualifications='$qua' , Address='$add' , teaching_exp = '$tec' , Contact_no_1='$con1' , contact_no_2 = '$con2' where Emailid='$a3'";

$h=mysqli_query($link,$q2);
header("location:after login.php");


}

?>
<?php
}


?>
