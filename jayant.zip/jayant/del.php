<?php

$link=mysqli_connect('localhost','root','','final');;
$a=$_GET['Emailid'];

$q="delete from info where Emailid='$a'";
$q1=mysqli_query($link,$q);
header("location:after login.php");
?>