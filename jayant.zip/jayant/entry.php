<html>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {
  box-sizing:border-box;
}

input[type=text]{
  width: 100%;
  padding: 10px;
  margin: 5px 0 10px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
input[type=text]:focus{
  background-color: #ddd;
  outline: none;
}
button,input[type=submit] {
  background-color: lightblue;
  color: black;
  font-size: 20px;
  padding: 14px 10px;
  margin: 8px 0;
  width: 100%;
}
button:hover {
  opacity:1;
}
.container {
  padding: 16px;
}
.modal {
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto; 
  background-color: #474e5d;
  padding-top: 50px;
}

.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; 
  border: 1px solid #888;
  width: 80%; }


.mainh {
	padding=20xp;
	background-color : lightblue;
	float:center;
	width:100%;
}

</style>
<body >
<div class="modal">

<form class="modal-content" action="#" method="post" enctype="multipart/form-data">

<div class="mainh">
<h1 align="center">NEW ENTRY FORM</h1>
</div>

<div class="container">
         First Name:
         <input type="text" name="t1" placeholder="Enter first name"> 
		 Last Name:
         <input type="text" name="t2" placeholder="Enter last name"> 
        <br> 
		<br>
Gender<input type="radio" name="r" value="Male">Male
<input type="radio" name="r" value="Female">Female
<input type="radio" name="r" value="Any Other">Any Other<br><br>

Email-Id:
   <input type="text" name="t3" placeholder="Enter emai-id"><br>
Skills:<br>
<input type="checkbox" name="language" value="c">C<br>
        <input type="checkbox" name="language" value="c++">C++<br>
        <input type="checkbox" name="language" value="html">HTML<br>
        <input type="checkbox" name="language" value="python">Phython<br>
		<input type="rext" name="sk" placeholder="Enter skill"><br>
		<br>
Teaching Experience: 
  <input type="text" name="t4" placeholder="Enter teaching experience"><br>
Qualification: 
  <input type="text" name="qual" placeholder="Enter qualification "><br>
Address: 
  <input type="text" name="add" placeholder="Enter address"><br>
Contact No.: 
  <input type="text" name="con1"placeholder="Enter contact number"><br>
Another No.: 
  <input type="text" name="con2"placeholder="Enter another contact number" ><br>
Marital Status: 
  <input type="radio" name="m" value="married">Married
  <input type="radio" name="m" value="unmarried">Unmarried<br>
<input type="date" name="dob" placeholder="dob">
<br>
<label>Select Image:</label>
<input type="file" name="image"/>

				  <br /><br />
                 
              					 

<input type="submit" name="s" value="Submit">





<?php
$a1=$_POST['t1'];
$a2=$_POST['t2'];
$g=$_POST['r'];
$a3=$_POST['t3'];
$C=$_POST['language'];
$dob=$_POST['dob'];
$name=$a1." ".$a2;
$tec=$_POST['t4'];
$qua=$_POST['qual'];
$add=$_POST['add'];
$con1=$_POST['con1'];
$con2=$_POST['con2'];
$stat=$_POST['m'];
$ski=$_POST['sk'];
$skill=$C." ".$ski;

$link=mysqli_connect('localhost','root','','final');
	$file_name=$_FILES['image']['name'];
$file_size=$_FILES['image']['size'];
$file_tmp=$_FILES['image']['tmp_name'];
$file_type=$_FILES['image']['type'];
$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
$file_store=$file_name;
$file_store="image/".$file_name;
move_uploaded_file($file_tmp,$file_store);	
		$qry="insert into info values('','$name','$g','$a3','$skill','$tec','$qua','$add','$con1','$con2','$dob','$stat','$file_store')";
		$doc1=mysqli_query($link,$qry);
header("location:after login.php");
?>
