<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing:border-box;
}
.header {
  background-image: url('logo.jpg');
  background-color:aliceblue;
  background-repeat: no-repeat;
  padding: 65px ;
}
body{
	 background-image:url('clg.jpg');
	 background-repeat:no-repeat;
	 background-color: rgba(0,0,0, 0.4);
	 background-size:1400px 800px;
}
input[type=text] ,input[type=password]{
  width: 100%;
  padding: 10px;
  margin: 5px 0 10px 0;
  display: inline-block;
  border: none;
background-color:rgba(175,238,238,0.8);
}
input[type=submit]{
  padding: 6px;
  width:90px;
height:45px;
margin-left:42px
  display: inline-block;
 background: skyblue;
}

.main {
  background-color: ;
  padding:20px;
  float:left;
  width:80%;
}
.righth
{
	background-color : lightblue;
	float:left;
	width:20%;
}
.right {
  background-color : aliceblue;
  padding:20px;
  float:left;
  width:20%;
}
.mainh
{	
background-color: rgba(0,0,0,0.3);

	color:white;
	padding:10px;    
	float:left;
	width:100%;
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
  background-color: lavender;
  background-image:url('chancellor.jpg');
  background-repeat:no-repeat;
  background-size:100px 100px;
  padding: 6px;
  
}
table {   
    border-radius:25px;   

  
	background-color:	rgb(224,255,255,0.9);
    border-collapse: collapse;
	text-color:white;
    width: 100%; 
}
 td{
  text-align: center;
  padding: 8px;
}
h3{ width:15%;
	background-color:aliceblue;
	font-family:arial;
}
img {
   border-radius: 50%;
   height: $imageSmall;
   width: $imageSmall;
}
</style>
</head>
<body>
<div class="header">
</div>

<div class="mainh">
<h1>FACULTY DIRECTORY</h1>
</div>
<div class="main">
  
   <form action="#" method="post" >  
    <h3>Teacher's Name:</h3>    
   <input type="text" name="T" placeholder="Enter teacher's name">
   <input type="submit" name="S" value="Search" >
    </form>
   <br>
   <form action="#" method="post" >
    <h3>Teacher's Email:</h3> 
   <input type="text" name="T1" placeholder="Enter teacher's email id">
   <input type="submit" name="S1" value="Search">
    </form>
  
</div>
<div class="righth">
<p><center><b> Admin Login</b></center></p>
</div>
<div class="right">
  <p><form action="#" method="post" >
		Username
		<input type="text" name="usern" placeholder="Enter your username"><br>
	
		Password
		<input type="password" name="pass" placeholder="Enter your password"><br>

         
		<input type="submit" name="s" value="Submit"></form></p>
</div>
<div class="footer"> <pre><p>
             Shri Purushottamdas Pasari
             Chancellor - SVVV, Chairman-Shri Vaishnav Group of Institutions, Indore
</pre></p>
</div>
</body>
</html>
<table>

<?php
$x=$_POST['T'];
if(isset ($_POST['S']))
    {
		$link=mysqli_connect("localhost","root","","final");
        $q="select * from info where Name='$x'";
        $q1=mysqli_query($link,$q);
		while($a=mysqli_fetch_array($q1))
 { 
      echo"<h3>Search Results:</h3>";  
	echo "<tr>";
    echo "<td>";
    echo "<img src='$a[1]' width='100' height='100' />";
    echo $a[12];
    echo "</td>";
    echo "<td>";
	echo $a[1];
	echo "<br>Qualification : "; echo $a[6];
	echo "</td>";
	echo "<td>";

	echo "<br>Skills : "; echo $a[4];
	echo "<br>Experience : "; echo $a[5];
	echo "</td>";
	echo "<td>";
	echo "<br>Gender : "; echo $a[2];
	echo "<br>DoB. : "; echo $a[10];
		echo "<br>Merital Status : "; echo $a[11];
	echo"</td>";
	echo "<td>";
	echo"Address : ";echo $a[7];
	echo "</td>";	
    echo "<td>";
   echo "<br>Email-Id : "; echo$a[3];
   	echo "<br>Contact No. : "; echo $a[8] ; echo " , "; echo $a[9];
   echo "</td>"; 
   echo "</tr>";
 }
	}	


$y=$_POST['T1'];
if(isset ($_POST['S1']))
    {
		$link=mysqli_connect("localhost","root","","final");
        $q="select * from info where Emailid='$y'";
        $q1=mysqli_query($link,$q);
		while($a=mysqli_fetch_array($q1))
 { 
    echo"<h3>Search Results:</h3>";   
	echo "<tr>";
     echo "<td>";
    echo "<img src='$a[1]' width='100' height='100' />";
    echo $a[12];
    echo "</td>";
    echo "<td>";
	echo $a[1];
	echo "<br>Qualification : "; echo $a[6];
	echo "</td>";
	echo "<td>";

	echo "<br>Skills : "; echo $a[4];
	echo "<br>Experience : "; echo $a[5];
	echo "</td>";
	echo "<td>";
	echo "<br>Gender : "; echo $a[2];
	echo "<br>DoB. : "; echo $a[10];
		echo "<br>Merital Status : "; echo $a[11];
	echo"</td>";
	echo "<td>";
	echo"Address : ";echo $a[7];
	echo "</td>";	
    echo "<td>";
   echo "<br>Email-Id : "; echo$a[3];
   	echo "<br>Contact No. : "; echo $a[8] ; echo " , "; echo $a[9];
   echo "</td>"; 
   echo "</tr>";
 }
	}
	echo "</table>";
$a=$_POST['usern'];
$b=$_POST['pass'];
if(isset ($_POST['s']))
{
	if($a=="jayantbansal" )
	{
		if($b==1234567)
		{
	         echo "login succes";
			 header("location:after login.php");
		}
	}
}


?>